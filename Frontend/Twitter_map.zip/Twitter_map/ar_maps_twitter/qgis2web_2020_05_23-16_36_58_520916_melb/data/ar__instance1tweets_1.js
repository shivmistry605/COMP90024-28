var json_ar__instance1tweets_1 = {
"type": "FeatureCollection",
"name": "ar__instance1tweets_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1256406276277276700", "city": "Marysville", "user": "jabber12130", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 145.74073413, -37.51065816 ] } },
{ "type": "Feature", "properties": { "id": "1256688855656345600", "city": "Barry", "user": "ftoom12122", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 149.267, -33.647 ] } },
{ "type": "Feature", "properties": { "id": "1259263554810794000", "city": "Sydney", "user": "naiff994", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.20130562, -33.87237302 ] } },
{ "type": "Feature", "properties": { "id": "1260346201016279000", "city": "Sydney", "user": "Bedronet", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.20797, -33.86751 ] } },
{ "type": "Feature", "properties": { "id": "1260663884047761400", "city": "Wollongong", "user": "SalmannShammari", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 150.8860794, -34.4276231 ] } },
{ "type": "Feature", "properties": { "id": "1261042810762846200", "city": "Sydney", "user": "daphnethetree", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.19499105, -33.87148514 ] } },
{ "type": "Feature", "properties": { "id": "1261681287728902100", "city": "Sydney", "user": "Hoooba2011", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.20797, -33.86751 ] } },
{ "type": "Feature", "properties": { "id": "1262063487985074200", "city": "Melbourne", "user": "iiisalem_", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 145.0422836, -37.8895005 ] } },
{ "type": "Feature", "properties": { "id": "1262113421027422200", "city": "Sydney", "user": "AbdTorah", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.153608319999989, -33.95843208 ] } },
{ "type": "Feature", "properties": { "id": "1262511063687483400", "city": "Sydney", "user": "nashatfozi", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.0703, -33.8431 ] } },
{ "type": "Feature", "properties": { "id": "1262772011106885600", "city": "Melbourne", "user": "alaribi11", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 144.9527789, -37.8155986 ] } },
{ "type": "Feature", "properties": { "id": "1262839507251912700", "city": "Sydney", "user": "AbdTorah", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.153608319999989, -33.95843208 ] } },
{ "type": "Feature", "properties": { "id": "1263007690139160600", "city": "Sydney", "user": "BeetoBeeto97", "lang": "ar" }, "geometry": { "type": "Point", "coordinates": [ 151.0027428, -33.81793535 ] } }
]
}
