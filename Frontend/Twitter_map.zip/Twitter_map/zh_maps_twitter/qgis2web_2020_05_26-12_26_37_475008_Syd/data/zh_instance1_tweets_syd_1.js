var json_zh_instance1_tweets_syd_1 = {
"type": "FeatureCollection",
"name": "zh_instance1_tweets_syd_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1256838992546287600", "city": "Sydney", "user": "kelindns", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 151.20797, -33.86751 ] } }
]
}
