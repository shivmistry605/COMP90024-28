var json_zh_instance1_tweets_melb_1 = {
"type": "FeatureCollection",
"name": "zh_instance1_tweets_melb_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "1256406250474164200", "city": "Melbourne", "user": "ao3sm345", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.0411499, -37.94838 ] } },
{ "type": "Feature", "properties": { "id": "1256966039570694100", "city": "Melbourne", "user": "Guxito1", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.1296, -37.9148 ] } },
{ "type": "Feature", "properties": { "id": "1257599868253724700", "city": "Melbourne", "user": "PyxBadassalex", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.963057600000013, -37.8136276 ] } },
{ "type": "Feature", "properties": { "id": "1257615482774904800", "city": "Melbourne", "user": "Guxito1", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.9661, -37.8156 ] } },
{ "type": "Feature", "properties": { "id": "1257701471845527600", "city": "Melbourne", "user": "pokapokausagi", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.7371882, -37.90805122 ] } },
{ "type": "Feature", "properties": { "id": "1258325403845955600", "city": "Melbourne", "user": "Eadger_Hu", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.966, -37.8169 ] } },
{ "type": "Feature", "properties": { "id": "1258516944497467400", "city": "Melbourne", "user": "sxnwj4231", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.15434891000001, -37.80538236 ] } },
{ "type": "Feature", "properties": { "id": "1258907312825274400", "city": "Melbourne", "user": "sxnwj4231", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.15434891000001, -37.80538236 ] } },
{ "type": "Feature", "properties": { "id": "1258908049219227600", "city": "Melbourne", "user": "sxnwj4231", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.15434891000001, -37.80538236 ] } },
{ "type": "Feature", "properties": { "id": "1259999522115240000", "city": "Melbourne", "user": "ao3sm345", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.95793534, -37.80728606 ] } },
{ "type": "Feature", "properties": { "id": "1260869930406166500", "city": "Melbourne", "user": "Guxito1", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.9661, -37.8156 ] } },
{ "type": "Feature", "properties": { "id": "1260959923749478400", "city": "Melbourne", "user": "backpackerjim", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.9563, -37.7773899 ] } },
{ "type": "Feature", "properties": { "id": "1261996530166378500", "city": "Melbourne", "user": "Guxito1", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.9661, -37.8156 ] } },
{ "type": "Feature", "properties": { "id": "1262350879740526600", "city": "Melbourne", "user": "ao3sm345", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.05215, -37.8539 ] } },
{ "type": "Feature", "properties": { "id": "1262749598566633500", "city": "Melbourne", "user": "youzuohaoxuan", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.0422836, -37.8895005 ] } },
{ "type": "Feature", "properties": { "id": "1263126674033557500", "city": "Melbourne", "user": "lyc18610157480", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.04335, -37.82393 ] } },
{ "type": "Feature", "properties": { "id": "1263135743960141800", "city": "Melbourne", "user": "Guxito1", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 144.9661, -37.8156 ] } },
{ "type": "Feature", "properties": { "id": "1263381769509900300", "city": "Melbourne", "user": "sxnwj4231", "lang": "zh" }, "geometry": { "type": "Point", "coordinates": [ 145.15434891000001, -37.80538236 ] } }
]
}
