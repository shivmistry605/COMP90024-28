var json_el_tweets_1 = {
"type": "FeatureCollection",
"name": "el_tweets_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "494744205290266624", "city": "Melbourne", "user": "elenimaltezoy" }, "geometry": { "type": "Point", "coordinates": [ 144.93261295, -37.80048227 ] } },
{ "type": "Feature", "properties": { "id": "495064547292479488", "city": "Melbourne", "user": "elenimaltezoy" }, "geometry": { "type": "Point", "coordinates": [ 144.830499159999988, -37.86686651 ] } },
{ "type": "Feature", "properties": { "id": "495416382591234048", "city": "Melbourne", "user": "elenimaltezoy" }, "geometry": { "type": "Point", "coordinates": [ 144.82117491, -37.86834601 ] } },
{ "type": "Feature", "properties": { "id": "497267577316315136", "city": "Melbourne", "user": "elenimaltezoy" }, "geometry": { "type": "Point", "coordinates": [ 144.83041731, -37.86866339 ] } },
{ "type": "Feature", "properties": { "id": "504256235143585792", "city": "Melbourne", "user": "magda_vrettos" }, "geometry": { "type": "Point", "coordinates": [ 145.12008173000001, -37.9348219 ] } }
]
}
